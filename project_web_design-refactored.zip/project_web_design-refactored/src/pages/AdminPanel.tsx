import { useState, useCallback } from 'react';
import { Plus, Edit2, Trash2 } from 'lucide-react';
import type { Webapp, WebappFormData } from '../types/webapp';
import { iconMap, DEFAULT_CATEGORIES } from '../utils/helpers';
import { getIconComponent } from '../utils/helpers';

const DEFAULT_FORM: WebappFormData = {
  name: '',
  description: '',
  url: '',
  category: 'General',
  icon: 'Box',
  status: 'active',
  owner: '',
  version: '1.0.0',
  sort_order: 0,
};

interface AdminPanelProps {
  webapps: Webapp[];
  loading: boolean;
  onSave: (formData: WebappFormData, editingId?: string) => Promise<boolean>;
  onDelete: (id: string) => void;
}

export default function AdminPanel({ webapps, loading, onSave, onDelete }: AdminPanelProps) {
  const [formData, setFormData] = useState<WebappFormData>(DEFAULT_FORM);
  const [editingWebapp, setEditingWebapp] = useState<Webapp | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  const resetForm = useCallback(() => {
    setFormData(DEFAULT_FORM);
    setEditingWebapp(null);
  }, []);

  const handleEdit = useCallback((app: Webapp) => {
    setEditingWebapp(app);
    setFormData({
      name: app.name,
      description: app.description || '',
      url: app.url,
      category: app.category || 'General',
      icon: app.icon || 'Box',
      status: app.status as 'active' | 'maintenance',
      owner: app.owner || '',
      version: app.version || '1.0.0',
      sort_order: app.sort_order,
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await onSave(formData, editingWebapp?.id);
    if (success) resetForm();
  };

  const handleField = useCallback(
    <K extends keyof WebappFormData>(key: K, value: WebappFormData[K]) => {
      setFormData((prev) => ({ ...prev, [key]: value }));
    },
    []
  );

  const inputClass =
    'w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white outline-none focus:border-cyan-500 transition-all';

  return (
    <main className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold text-white text-glow-cyan">Admin Panel</h2>
        <button
          onClick={resetForm}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium bg-gradient-to-r from-cyan-500 to-pink-500 text-white hover:opacity-90 transition-all"
        >
          <Plus className="w-4 h-4" />
          Add Webapp
        </button>
      </div>

      {/* Form */}
      <div className="glass-card rounded-2xl p-6 mb-8">
        <h3 className="text-lg font-bold text-white mb-6">
          {editingWebapp ? 'Edit Webapp' : 'Add New Webapp'}
        </h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Name *</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => handleField('name', e.target.value)}
                className={inputClass}
                placeholder="Webapp Name"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">URL *</label>
              <input
                type="url"
                required
                value={formData.url}
                onChange={(e) => handleField('url', e.target.value)}
                className={inputClass}
                placeholder="https://..."
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-2">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => handleField('description', e.target.value)}
              className={`${inputClass} resize-none`}
              rows={2}
              placeholder="Webapp description..."
            />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Category</label>
              <select
                value={formData.category}
                onChange={(e) => handleField('category', e.target.value)}
                className={inputClass}
              >
                {DEFAULT_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat} className="bg-guardian-navy">
                    {cat}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Icon</label>
              <select
                value={formData.icon}
                onChange={(e) => handleField('icon', e.target.value)}
                className={inputClass}
              >
                {Object.keys(iconMap).map((icon) => (
                  <option key={icon} value={icon} className="bg-guardian-navy">
                    {icon}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Status</label>
              <select
                value={formData.status}
                onChange={(e) => handleField('status', e.target.value as 'active' | 'maintenance')}
                className={inputClass}
              >
                <option value="active" className="bg-guardian-navy">Active</option>
                <option value="maintenance" className="bg-guardian-navy">Maintenance</option>
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Version</label>
              <input
                type="text"
                value={formData.version}
                onChange={(e) => handleField('version', e.target.value)}
                className={inputClass}
                placeholder="1.0.0"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Owner/PIC</label>
              <input
                type="text"
                value={formData.owner}
                onChange={(e) => handleField('owner', e.target.value)}
                className={inputClass}
                placeholder="Owner name"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Sort Order</label>
              <input
                type="number"
                value={formData.sort_order}
                onChange={(e) => handleField('sort_order', parseInt(e.target.value) || 0)}
                className={inputClass}
                placeholder="0"
              />
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              className="flex-1 py-3 rounded-lg font-medium bg-gradient-to-r from-cyan-500 to-pink-500 text-white hover:opacity-90 transition-all"
            >
              {editingWebapp ? 'Update Webapp' : 'Add Webapp'}
            </button>
            {editingWebapp && (
              <button
                type="button"
                onClick={resetForm}
                className="px-6 py-3 rounded-lg font-medium text-gray-400 hover:text-white border border-white/10 hover:border-white/20 transition-all"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Webapp List */}
      <div className="glass-card rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-white/10">
          <h3 className="text-lg font-bold text-white">Manage Webapps</h3>
        </div>
        <div className="divide-y divide-white/10">
          {loading ? (
            <div className="p-8 text-center text-gray-400">Loading...</div>
          ) : webapps.length === 0 ? (
            <div className="p-8 text-center text-gray-400">No webapps yet.</div>
          ) : (
            webapps.map((app) => {
              const Icon = getIconComponent(app.icon);
              return (
                <div
                  key={app.id}
                  className="p-4 flex items-center justify-between hover:bg-white/5 transition-all"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                      <Icon className="w-5 h-5 text-cyan-400" />
                    </div>
                    <div>
                      <p className="font-medium text-white">{app.name}</p>
                      <p className="text-xs text-gray-500">
                        {app.category} • {app.status} • {app.click_count} clicks
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleEdit(app)}
                      className="p-2 rounded-lg text-cyan-400 hover:bg-cyan-500/10 transition-all"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onDelete(app.id)}
                      className="p-2 rounded-lg text-pink-400 hover:bg-pink-500/10 transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </main>
  );
}
