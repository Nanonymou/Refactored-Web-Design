import { useMemo, useState, useCallback } from 'react';
import { Package, CheckCircle2, AlertTriangle, BarChart3 } from 'lucide-react';
import type { Webapp } from '../types/webapp';
import WebAppCard from '../components/WebAppCard';
import SearchBar from '../components/SearchBar';

interface DashboardProps {
  webapps: Webapp[];
  loading: boolean;
  onOpenWebApp: (app: Webapp) => void;
}

export default function Dashboard({ webapps, loading, onOpenWebApp }: DashboardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');

  const categories = useMemo(
    () => ['All', ...new Set(webapps.map((app) => app.category || 'General'))],
    [webapps]
  );

  const stats = useMemo(
    () => ({
      total: webapps.length,
      active: webapps.filter((a) => a.status === 'active').length,
      maintenance: webapps.filter((a) => a.status === 'maintenance').length,
      totalClicks: webapps.reduce((sum, a) => sum + a.click_count, 0),
    }),
    [webapps]
  );

  const filteredWebapps = useMemo(
    () =>
      webapps.filter((app) => {
        const q = searchQuery.toLowerCase();
        const matchSearch =
          app.name.toLowerCase().includes(q) ||
          (app.description?.toLowerCase().includes(q) ?? false);
        const matchCategory = selectedCategory === 'All' || app.category === selectedCategory;
        const matchStatus = selectedStatus === 'All' || app.status === selectedStatus;
        return matchSearch && matchCategory && matchStatus;
      }),
    [webapps, searchQuery, selectedCategory, selectedStatus]
  );

  const handleSearchChange = useCallback((q: string) => setSearchQuery(q), []);
  const handleCategoryChange = useCallback((c: string) => setSelectedCategory(c), []);
  const handleStatusChange = useCallback((s: string) => setSelectedStatus(s), []);

  return (
    <main className="max-w-7xl mx-auto px-4 py-8">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="glass-card rounded-xl p-4 glow-cyan animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
              <Package className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{stats.total}</p>
              <p className="text-xs text-gray-400">Total Webapps</p>
            </div>
          </div>
        </div>
        <div className="glass-card rounded-xl p-4 glow-pink animate-fade-in animate-delay-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-green-400">{stats.active}</p>
              <p className="text-xs text-gray-400">Active</p>
            </div>
          </div>
        </div>
        <div className="glass-card rounded-xl p-4 animate-fade-in animate-delay-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-yellow-400">{stats.maintenance}</p>
              <p className="text-xs text-gray-400">Maintenance</p>
            </div>
          </div>
        </div>
        <div className="glass-card rounded-xl p-4 glow-gold animate-fade-in animate-delay-300">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-yellow-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-guardian-gold text-glow-gold">
                {stats.totalClicks}
              </p>
              <p className="text-xs text-gray-400">Total Clicks</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filter */}
      <SearchBar
        searchQuery={searchQuery}
        selectedCategory={selectedCategory}
        selectedStatus={selectedStatus}
        categories={categories}
        onSearchChange={handleSearchChange}
        onCategoryChange={handleCategoryChange}
        onStatusChange={handleStatusChange}
      />

      {/* Content */}
      {loading ? (
        <div className="text-center py-20">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-cyan-500 to-pink-500 animate-spin" />
          <p className="text-gray-400">Loading webapps...</p>
        </div>
      ) : filteredWebapps.length === 0 ? (
        <div className="text-center py-20">
          <Package className="w-16 h-16 mx-auto mb-4 text-gray-600" />
          <p className="text-gray-400">No webapps found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredWebapps.map((app, index) => (
            <WebAppCard key={app.id} app={app} index={index} onOpen={onOpenWebApp} />
          ))}
        </div>
      )}
    </main>
  );
}
