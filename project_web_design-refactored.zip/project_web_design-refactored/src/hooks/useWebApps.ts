import { useState, useEffect, useCallback } from 'react';
import type { Webapp, WebappFormData } from '../types/webapp';
import {
  getWebApps,
  getWebAppsAdmin,
  createWebApp,
  updateWebApp,
  deleteWebApp,
  incrementClickCount,
} from '../services/webapp.service';
import { useToast } from '../context/ToastContext';

export function useWebApps() {
  const [webapps, setWebapps] = useState<Webapp[]>([]);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  const fetchWebapps = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getWebApps();
      setWebapps(data);
    } catch (err) {
      showToast('Failed to load webapps. Please refresh.', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  const fetchWebappsAdmin = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getWebAppsAdmin();
      setWebapps(data);
    } catch (err) {
      showToast('Failed to load webapps.', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    fetchWebapps();
  }, [fetchWebapps]);

  const openWebApp = useCallback(async (app: Webapp) => {
    if (app.url === '#') return;
    // Open immediately to avoid popup blocker (must happen synchronously)
    window.open(app.url, '_blank', 'noopener,noreferrer');
    // Increment in background
    try {
      await incrementClickCount(app.id);
      // Silently refresh click counts
      const data = await getWebApps();
      setWebapps(data);
    } catch {
      // Non-critical failure, don't bother the user
    }
  }, []);

  const saveWebApp = useCallback(
    async (formData: WebappFormData, adminPassword: string, editingId?: string) => {
      try {
        if (editingId) {
          await updateWebApp(editingId, formData, adminPassword);
          showToast('Webapp updated successfully!', 'success');
        } else {
          await createWebApp(formData, adminPassword);
          showToast('Webapp added successfully!', 'success');
        }
        await fetchWebappsAdmin();
        return true;
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Failed to save webapp.', 'error');
        return false;
      }
    },
    [showToast, fetchWebappsAdmin]
  );

  const removeWebApp = useCallback(
    async (id: string, adminPassword: string) => {
      try {
        await deleteWebApp(id, adminPassword);
        showToast('Webapp deleted.', 'success');
        await fetchWebappsAdmin();
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Failed to delete webapp.', 'error');
      }
    },
    [showToast, fetchWebappsAdmin]
  );

  return {
    webapps,
    loading,
    fetchWebapps,
    fetchWebappsAdmin,
    openWebApp,
    saveWebApp,
    removeWebApp,
  };
}
