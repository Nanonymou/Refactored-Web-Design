import { createClient } from '@supabase/supabase-js';
import type { Webapp, WebappFormData } from '../types/webapp';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const EDGE_FUNCTION_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-webapps`;

// ─── Public API ────────────────────────────────────────────────────────────────

/** Fetch all webapps (public, uses anon key via Supabase client) */
export async function getWebApps(): Promise<Webapp[]> {
  const { data, error } = await supabase
    .from('webapps')
    .select('*')
    .order('sort_order', { ascending: true })
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return data ?? [];
}

/** Increment click count for a webapp (public, fire-and-forget) */
export async function incrementClickCount(id: string): Promise<void> {
  await fetch(`${EDGE_FUNCTION_URL}/click/${id}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  });
}

// ─── Admin API (require adminPassword header) ──────────────────────────────────

/** Fetch all webapps via Edge Function (admin) */
export async function getWebAppsAdmin(): Promise<Webapp[]> {
  const response = await fetch(`${EDGE_FUNCTION_URL}/list`, {
    headers: { 'Content-Type': 'application/json' },
  });
  const result = await response.json();
  if (result.error) throw new Error(result.error);
  return result.data ?? [];
}

/** Create a new webapp (admin) */
export async function createWebApp(formData: WebappFormData, adminPassword: string): Promise<void> {
  const payload = {
    ...formData,
    sort_order: parseInt(String(formData.sort_order)),
    adminPassword,
  };
  const response = await fetch(`${EDGE_FUNCTION_URL}/create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const result = await response.json();
  if (result.error) throw new Error(result.error);
}

/** Update an existing webapp (admin) */
export async function updateWebApp(
  id: string,
  formData: WebappFormData,
  adminPassword: string
): Promise<void> {
  const payload = {
    ...formData,
    sort_order: parseInt(String(formData.sort_order)),
    adminPassword,
  };
  const response = await fetch(`${EDGE_FUNCTION_URL}/update/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const result = await response.json();
  if (result.error) throw new Error(result.error);
}

/** Delete a webapp (admin) */
export async function deleteWebApp(id: string, adminPassword: string): Promise<void> {
  const response = await fetch(`${EDGE_FUNCTION_URL}/delete/${id}`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ adminPassword }),
  });
  const result = await response.json();
  if (result.error) throw new Error(result.error);
}
