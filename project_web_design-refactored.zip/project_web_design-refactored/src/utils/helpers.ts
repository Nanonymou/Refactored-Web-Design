import {
  Server,
  Video,
  Heart,
  Calculator,
  Package,
  Box,
  Activity,
  Settings,
  BarChart3,
} from 'lucide-react';

export const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Server,
  Video,
  Heart,
  Calculator,
  Package,
  Box,
  Activity,
  Settings,
  BarChart3,
};

export const categoryColors: Record<string, string> = {
  QHSE: 'from-cyan-500/20 to-cyan-600/10 border-cyan-500/30',
  Meeting: 'from-pink-500/20 to-pink-600/10 border-pink-500/30',
  HR: 'from-gold-500/20 to-gold-600/10 border-yellow-500/30',
  Finance: 'from-green-500/20 to-green-600/10 border-green-500/30',
  General: 'from-gray-500/20 to-gray-600/10 border-gray-500/30',
};

export const particleColors: Record<string, string> = {
  cyan: 'rgba(0, 212, 255, 0.4)',
  pink: 'rgba(255, 0, 110, 0.4)',
  gold: 'rgba(255, 215, 0, 0.4)',
};

export function getParticleColor(color: string): string {
  return particleColors[color] || particleColors.cyan;
}

export function getIconComponent(iconName: string | null): React.ComponentType<{ className?: string }> {
  return iconMap[iconName || 'Box'] || Box;
}

export function generateParticles() {
  return Array.from({ length: 50 }, (_, i) => ({
    id: i,
    size: Math.random() * 4 + 2,
    left: Math.random() * 100,
    duration: Math.random() * 20 + 15,
    delay: Math.random() * 20,
    color: ['cyan', 'pink', 'gold'][Math.floor(Math.random() * 3)],
  }));
}

export const DEFAULT_CATEGORIES = ['General', 'QHSE', 'Meeting', 'HR', 'Finance'];
