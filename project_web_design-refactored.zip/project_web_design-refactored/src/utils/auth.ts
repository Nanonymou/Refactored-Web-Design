/**
 * Validates admin password against environment variable.
 * Password is stored in VITE_ADMIN_PASSWORD env var, never hardcoded.
 */
export function validateAdminPassword(input: string): boolean {
  const adminPassword = import.meta.env.VITE_ADMIN_PASSWORD;
  if (!adminPassword) {
    console.error('VITE_ADMIN_PASSWORD environment variable is not set.');
    return false;
  }
  return input === adminPassword;
}
