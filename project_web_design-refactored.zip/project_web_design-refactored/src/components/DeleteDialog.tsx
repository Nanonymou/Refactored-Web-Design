import { Trash2 } from 'lucide-react';

interface DeleteDialogProps {
  onConfirm: () => void;
  onCancel: () => void;
}

export default function DeleteDialog({ onConfirm, onCancel }: DeleteDialogProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="glass-card rounded-2xl p-8 w-full max-w-md mx-4 animate-fade-in">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-pink-500/20 flex items-center justify-center">
            <Trash2 className="w-8 h-8 text-pink-400" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Delete Webapp?</h3>
          <p className="text-gray-400 mb-6">
            This action cannot be undone. The webapp will be permanently removed.
          </p>
          <div className="flex gap-3">
            <button
              onClick={onCancel}
              className="flex-1 py-3 rounded-lg font-medium text-gray-400 border border-white/10 hover:border-white/20 hover:text-white transition-all"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              className="flex-1 py-3 rounded-lg font-medium bg-pink-500/20 text-pink-400 border border-pink-500/30 hover:bg-pink-500/30 transition-all"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
