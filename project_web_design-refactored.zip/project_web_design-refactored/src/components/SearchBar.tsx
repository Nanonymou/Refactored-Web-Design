import React from 'react';
import { Search, Filter, ChevronDown } from 'lucide-react';

interface SearchBarProps {
  searchQuery: string;
  selectedCategory: string;
  selectedStatus: string;
  categories: string[];
  onSearchChange: (q: string) => void;
  onCategoryChange: (c: string) => void;
  onStatusChange: (s: string) => void;
}

const SearchBar = React.memo(function SearchBar({
  searchQuery,
  selectedCategory,
  selectedStatus,
  categories,
  onSearchChange,
  onCategoryChange,
  onStatusChange,
}: SearchBarProps) {
  const selectClass =
    'bg-transparent border-none outline-none text-white cursor-pointer';

  return (
    <div className="flex flex-col md:flex-row gap-4 mb-8">
      {/* Search Input */}
      <div className="flex-1 glass-card rounded-xl px-4 py-2 flex items-center gap-3">
        <Search className="w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search webapps..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="w-full bg-transparent border-none outline-none text-white placeholder-gray-500"
        />
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <div className="glass-card rounded-xl px-4 py-2 flex items-center gap-2">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={selectedCategory}
            onChange={(e) => onCategoryChange(e.target.value)}
            className={selectClass}
          >
            {categories.map((cat) => (
              <option key={cat} value={cat} className="bg-guardian-navy">
                {cat}
              </option>
            ))}
          </select>
          <ChevronDown className="w-4 h-4 text-gray-400" />
        </div>
        <div className="glass-card rounded-xl px-4 py-2 flex items-center gap-2">
          <select
            value={selectedStatus}
            onChange={(e) => onStatusChange(e.target.value)}
            className={selectClass}
          >
            <option value="All" className="bg-guardian-navy">All Status</option>
            <option value="active" className="bg-guardian-navy">Active</option>
            <option value="maintenance" className="bg-guardian-navy">Maintenance</option>
          </select>
          <ChevronDown className="w-4 h-4 text-gray-400" />
        </div>
      </div>
    </div>
  );
});

export default SearchBar;
