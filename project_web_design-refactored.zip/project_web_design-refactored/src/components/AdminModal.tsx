import { useState } from 'react';
import { X } from 'lucide-react';
import { validateAdminPassword } from '../utils/auth';
import { useToast } from '../context/ToastContext';

interface AdminModalProps {
  onSuccess: (password: string) => void;
  onClose: () => void;
}

export default function AdminModal({ onSuccess, onClose }: AdminModalProps) {
  const [passwordInput, setPasswordInput] = useState('');
  const { showToast } = useToast();

  const handleLogin = () => {
    if (validateAdminPassword(passwordInput)) {
      onSuccess(passwordInput);
    } else {
      showToast('Invalid admin password.', 'error');
      setPasswordInput('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="glass-card rounded-2xl p-8 w-full max-w-md mx-4 animate-fade-in">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white">Admin Login</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-gray-400 mb-2">Password</label>
            <input
              type="password"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white outline-none focus:border-cyan-500 transition-all"
              placeholder="Enter admin password"
              autoFocus
            />
          </div>
          <button
            onClick={handleLogin}
            className="w-full py-3 rounded-lg font-medium bg-gradient-to-r from-cyan-500 to-pink-500 text-white hover:opacity-90 transition-all"
          >
            Login
          </button>
        </div>
      </div>
    </div>
  );
}
