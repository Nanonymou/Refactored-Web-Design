import React from 'react';
import { Activity, Settings } from 'lucide-react';
import type { ActiveSection } from '../types/webapp';

interface NavbarProps {
  isAuthenticated: boolean;
  activeSection: ActiveSection;
  onSectionChange: (section: ActiveSection) => void;
  onAdminClick: () => void;
  onLogout: () => void;
}

const Navbar = React.memo(function Navbar({
  isAuthenticated,
  activeSection,
  onSectionChange,
  onAdminClick,
  onLogout,
}: NavbarProps) {
  const navBtnClass = (section: ActiveSection) =>
    `px-4 py-2 rounded-lg text-sm font-medium transition-all ${
      activeSection === section
        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
        : 'text-gray-400 hover:text-white hover:bg-white/5'
    }`;

  return (
    <header className="sticky top-0 z-50 glass-card border-b border-cyan-500/20">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Brand */}
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-pink-500 flex items-center justify-center glow-cyan">
              <Activity className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white text-glow-cyan">
                Guardian AI Enterprise
              </h1>
              <p className="text-sm text-gray-400">Tools make by Nanogat</p>
            </div>
          </div>

          {/* Nav Buttons */}
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <>
                <button onClick={() => onSectionChange('dashboard')} className={navBtnClass('dashboard')}>
                  Dashboard
                </button>
                <button onClick={() => onSectionChange('admin')} className={navBtnClass('admin')}>
                  Admin Panel
                </button>
                <button
                  onClick={onLogout}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-pink-400 hover:bg-pink-500/10 border border-pink-500/30 transition-all"
                >
                  Logout
                </button>
              </>
            ) : (
              <button
                onClick={onAdminClick}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-cyan-400 hover:bg-cyan-500/10 border border-cyan-500/30 transition-all"
              >
                <Settings className="w-4 h-4" />
                Admin
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
});

export default Navbar;
