import { useMemo } from 'react';
import { generateParticles, getParticleColor } from '../utils/helpers';

export default function ParticleBackground() {
  // Particles are stable — generated once
  const particles = useMemo(() => generateParticles(), []);

  return (
    <div id="particles-container">
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="particle"
          style={{
            width: particle.size,
            height: particle.size,
            left: `${particle.left}%`,
            background: getParticleColor(particle.color),
            animationDuration: `${particle.duration}s`,
            animationDelay: `${particle.delay}s`,
          }}
        />
      ))}
    </div>
  );
}
