import React from 'react';
import { ExternalLink, Eye } from 'lucide-react';
import type { Webapp } from '../types/webapp';
import { categoryColors, getIconComponent } from '../utils/helpers';

interface WebAppCardProps {
  app: Webapp;
  index: number;
  onOpen: (app: Webapp) => void;
}

const WebAppCard = React.memo(function WebAppCard({ app, index, onOpen }: WebAppCardProps) {
  const Icon = getIconComponent(app.icon);
  const isActive = app.status === 'active';
  const isComingSoon = app.url === '#';
  const cardColor = categoryColors[app.category || 'General'] || categoryColors.General;

  return (
    <div
      className={`glass-card rounded-2xl overflow-hidden transition-all duration-300 hover:scale-[1.02] animate-fade-in bg-gradient-to-br ${cardColor} border hover:shadow-lg hover:shadow-cyan-500/10`}
      style={{ animationDelay: `${index * 50}ms` }}
    >
      <div className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div
            className={`w-14 h-14 rounded-xl flex items-center justify-center ${
              isActive ? 'bg-cyan-500/20 glow-cyan' : 'bg-yellow-500/20'
            }`}
          >
            <Icon className={`w-7 h-7 ${isActive ? 'text-cyan-400' : 'text-yellow-400'}`} />
          </div>
          <span
            className={`px-3 py-1 rounded-full text-xs font-medium ${
              isActive
                ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                : 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
            }`}
          >
            {isActive ? 'Active' : 'Maintenance'}
          </span>
        </div>

        {/* Info */}
        <h3 className="text-lg font-bold text-white mb-2">{app.name}</h3>
        <p className="text-sm text-gray-400 mb-4 line-clamp-2">{app.description}</p>

        {/* Meta */}
        <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
          <span className="px-2 py-1 rounded bg-white/5 border border-white/10">
            {app.category}
          </span>
          <span>v{app.version}</span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Eye className="w-3 h-3" />
            {app.click_count}
          </span>
        </div>

        {/* CTA Button */}
        <button
          onClick={() => onOpen(app)}
          disabled={isComingSoon}
          className={`w-full py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
            isComingSoon
              ? 'bg-gray-700/30 text-gray-500 cursor-not-allowed'
              : 'bg-gradient-to-r from-cyan-500/20 to-pink-500/20 text-white hover:from-cyan-500/30 hover:to-pink-500/30 border border-cyan-500/30 hover:border-cyan-400'
          }`}
        >
          <ExternalLink className="w-4 h-4" />
          {isComingSoon ? 'Coming Soon' : 'Open Webapp'}
        </button>
      </div>
    </div>
  );
});

export default WebAppCard;
