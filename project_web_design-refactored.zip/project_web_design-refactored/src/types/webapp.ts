export interface Webapp {
  id: string;
  name: string;
  description: string | null;
  url: string;
  category: string | null;
  icon: string | null;
  status: string;
  owner: string | null;
  version: string | null;
  click_count: number;
  created_at: string;
  updated_at: string;
  sort_order: number;
}

export interface WebappFormData {
  name: string;
  description: string;
  url: string;
  category: string;
  icon: string;
  status: 'active' | 'maintenance';
  owner: string;
  version: string;
  sort_order: number;
}

export type ActiveSection = 'dashboard' | 'admin';

export interface AppStats {
  total: number;
  active: number;
  maintenance: number;
  totalClicks: number;
}
