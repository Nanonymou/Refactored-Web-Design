import { useState, useCallback, useEffect } from 'react';
import type { ActiveSection, WebappFormData } from './types/webapp';
import { ToastProvider } from './context/ToastContext';
import { useWebApps } from './hooks/useWebApps';
import Navbar from './components/Navbar';
import AdminModal from './components/AdminModal';
import DeleteDialog from './components/DeleteDialog';
import ParticleBackground from './components/ParticleBackground';
import Dashboard from './pages/Dashboard';
import AdminPanel from './pages/AdminPanel';

function AppContent() {
  const [activeSection, setActiveSection] = useState<ActiveSection>('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  const { webapps, loading, fetchWebappsAdmin, openWebApp, saveWebApp, removeWebApp } =
    useWebApps();

  // Load admin data when entering admin section
  useEffect(() => {
    if (activeSection === 'admin' && isAuthenticated) {
      fetchWebappsAdmin();
    }
  }, [activeSection, isAuthenticated, fetchWebappsAdmin]);

  const handleAdminSuccess = useCallback((password: string) => {
    setAdminPassword(password);
    setIsAuthenticated(true);
    setShowAdminModal(false);
    setActiveSection('admin');
  }, []);

  const handleLogout = useCallback(() => {
    setIsAuthenticated(false);
    setAdminPassword('');
    setActiveSection('dashboard');
  }, []);

  const handleSave = useCallback(
    (formData: WebappFormData, editingId?: string) =>
      saveWebApp(formData, adminPassword, editingId),
    [saveWebApp, adminPassword]
  );

  const handleDeleteRequest = useCallback((id: string) => {
    setPendingDeleteId(id);
  }, []);

  const handleDeleteConfirm = useCallback(async () => {
    if (!pendingDeleteId) return;
    await removeWebApp(pendingDeleteId, adminPassword);
    setPendingDeleteId(null);
  }, [pendingDeleteId, removeWebApp, adminPassword]);

  return (
    <div className="min-h-screen bg-guardian-dark relative overflow-hidden">
      <ParticleBackground />

      <div className="relative z-10">
        <Navbar
          isAuthenticated={isAuthenticated}
          activeSection={activeSection}
          onSectionChange={setActiveSection}
          onAdminClick={() => setShowAdminModal(true)}
          onLogout={handleLogout}
        />

        {activeSection === 'dashboard' && (
          <Dashboard webapps={webapps} loading={loading} onOpenWebApp={openWebApp} />
        )}

        {activeSection === 'admin' && isAuthenticated && (
          <AdminPanel
            webapps={webapps}
            loading={loading}
            onSave={handleSave}
            onDelete={handleDeleteRequest}
          />
        )}
      </div>

      {showAdminModal && (
        <AdminModal
          onSuccess={handleAdminSuccess}
          onClose={() => setShowAdminModal(false)}
        />
      )}

      {pendingDeleteId && (
        <DeleteDialog
          onConfirm={handleDeleteConfirm}
          onCancel={() => setPendingDeleteId(null)}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AppContent />
    </ToastProvider>
  );
}
