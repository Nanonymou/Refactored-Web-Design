import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Admin password is stored as Supabase Edge Function secret (ADMIN_PASSWORD)
    const ADMIN_PASSWORD = Deno.env.get("ADMIN_PASSWORD") ?? "";

    const url = new URL(req.url);
    const path = url.pathname.split("/manage-webapps")[1] || "";

    const verifyAdmin = (body: Record<string, unknown>): boolean => {
      return Boolean(ADMIN_PASSWORD) && body.adminPassword === ADMIN_PASSWORD;
    };

    const jsonResponse = (data: unknown, status = 200) =>
      new Response(JSON.stringify(data), {
        status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    // GET /list — public
    if (req.method === "GET" && path === "/list") {
      const { data, error } = await supabase
        .from("webapps")
        .select("*")
        .order("sort_order", { ascending: true })
        .order("created_at", { ascending: false });

      if (error) return jsonResponse({ error: error.message }, 500);
      return jsonResponse({ data });
    }

    // POST /create — admin
    if (req.method === "POST" && path === "/create") {
      const body = await req.json();
      if (!verifyAdmin(body)) return jsonResponse({ error: "Unauthorized" }, 401);

      const { adminPassword: _, ...webappData } = body;
      const { data, error } = await supabase.from("webapps").insert([webappData]).select().single();

      if (error) return jsonResponse({ error: error.message }, 500);
      return jsonResponse({ data });
    }

    // PUT /update/:id — admin
    if (req.method === "PUT" && path.startsWith("/update/")) {
      const body = await req.json();
      if (!verifyAdmin(body)) return jsonResponse({ error: "Unauthorized" }, 401);

      const id = path.split("/update/")[1];
      const { adminPassword: _, id: _id, ...updateData } = body;
      const { data, error } = await supabase
        .from("webapps")
        .update({ ...updateData, updated_at: new Date().toISOString() })
        .eq("id", id)
        .select()
        .single();

      if (error) return jsonResponse({ error: error.message }, 500);
      return jsonResponse({ data });
    }

    // DELETE /delete/:id — admin
    if (req.method === "DELETE" && path.startsWith("/delete/")) {
      const body = await req.json();
      if (!verifyAdmin(body)) return jsonResponse({ error: "Unauthorized" }, 401);

      const id = path.split("/delete/")[1];
      const { error } = await supabase.from("webapps").delete().eq("id", id);

      if (error) return jsonResponse({ error: error.message }, 500);
      return jsonResponse({ success: true });
    }

    // POST /click/:id — public
    if (req.method === "POST" && path.startsWith("/click/")) {
      const id = path.split("/click/")[1];
      const { error } = await supabase.rpc("increment_click_count", { webapp_id: id });

      if (error) {
        // Fallback: manual increment
        const { data: current } = await supabase
          .from("webapps")
          .select("click_count")
          .eq("id", id)
          .single();

        await supabase
          .from("webapps")
          .update({ click_count: (current?.click_count || 0) + 1 })
          .eq("id", id);
      }

      return jsonResponse({ success: true });
    }

    return jsonResponse({ error: "Not found" }, 404);
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
