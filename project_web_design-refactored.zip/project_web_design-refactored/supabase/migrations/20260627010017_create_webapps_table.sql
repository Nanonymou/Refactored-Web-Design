/*
# Create webapps table for Guardian AI Enterprise Dashboard

1. New Tables
- `webapps`
- `id` (uuid, primary key)
- `name` (text, not null) - Webapp name
- `description` (text) - Webapp description
- `url` (text, not null) - Google Apps Script URL
- `category` (text) - Category/Tag for grouping
- `icon` (text) - Lucide icon name
- `status` (text, default 'active') - 'active' or 'maintenance'
- `owner` (text) - Owner/PIC
- `version` (text) - Version number
- `click_count` (integer, default 0) - Click/view counter
- `created_at` (timestamptz, default now)
- `updated_at` (timestamptz, default now)
- `sort_order` (integer, default 0) - Custom sort order

2. Security
- Enable RLS on `webapps`.
- Allow anon + authenticated CRUD (single-tenant public dashboard).
*/

CREATE TABLE IF NOT EXISTS webapps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  url text NOT NULL,
  category text DEFAULT 'General',
  icon text DEFAULT 'Box',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'maintenance')),
  owner text,
  version text DEFAULT '1.0.0',
  click_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  sort_order integer DEFAULT 0
);

ALTER TABLE webapps ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_webapps" ON webapps;
CREATE POLICY "anon_select_webapps" ON webapps FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_webapps" ON webapps;
CREATE POLICY "anon_insert_webapps" ON webapps FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_webapps" ON webapps;
CREATE POLICY "anon_update_webapps" ON webapps FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_webapps" ON webapps;
CREATE POLICY "anon_delete_webapps" ON webapps FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_webapps_category ON webapps(category);
CREATE INDEX IF NOT EXISTS idx_webapps_status ON webapps(status);
CREATE INDEX IF NOT EXISTS idx_webapps_sort_order ON webapps(sort_order);