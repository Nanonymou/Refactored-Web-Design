/*
# Fix RLS policies for webapps table

1. Security Changes
- Keep SELECT policy for anon/authenticated (public dashboard view)
- Remove INSERT/UPDATE/DELETE policies for anon/authenticated
- Only service role can perform write operations (via edge function)

2. Important Notes
- Frontend will use edge function for admin operations
- Edge function validates admin password before allowing writes
- Public dashboard remains readable without authentication
*/

-- Drop the overly permissive policies
DROP POLICY IF EXISTS "anon_insert_webapps" ON webapps;
DROP POLICY IF EXISTS "anon_update_webapps" ON webapps;
DROP POLICY IF EXISTS "anon_delete_webapps" ON webapps;

-- Keep only the SELECT policy for public dashboard view
-- (already exists, no change needed)